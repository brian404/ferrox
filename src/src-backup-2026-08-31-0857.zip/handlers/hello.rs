use bytes::Bytes;
use http_body_util::Full;
use hyper::{Request, Response};
use hyper::body::Incoming;
use anyhow::Result;

pub async fn handle_hello(_req: Request<Incoming>) -> Result<Response<Full<Bytes>>, hyper::Error> {
    let response = Response::new(Full::from(Bytes::from("Hello from Ferrox!")));
    Ok(crate::headers::add_common_headers(response))
}
