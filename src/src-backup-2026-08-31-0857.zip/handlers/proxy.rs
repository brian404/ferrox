use anyhow::Result;
use bytes::Bytes;
use http_body_util::{BodyExt, Full};
use hyper::body::Incoming;
use hyper::client::conn::http1::Builder as ClientBuilder;
use hyper::{header, Request, Response, StatusCode};
use hyper_util::rt::TokioIo;
use std::net::SocketAddr;
use std::sync::Arc;
use tokio::io::copy_bidirectional;
use tokio::net::TcpStream;
use tokio::time::{timeout, Duration};

use crate::config::Config;

pub async fn proxy_request(
    mut req: Request<Incoming>,
    config: Arc<Config>,
    peer: SocketAddr,
) -> Result<Response<Full<Bytes>>, hyper::Error> {
    let upstream = config.proxy_upstream.clone();

    let is_websocket_upgrade = req
        .headers()
        .get(header::UPGRADE)
        .map_or(false, |v| v.as_bytes().eq_ignore_ascii_case(b"websocket"))
        && req
            .headers()
            .get(header::CONNECTION)
            .and_then(|v| v.to_str().ok())
            .map_or(false, |v| v.to_lowercase().contains("upgrade"));

    if is_websocket_upgrade {
        return proxy_websocket(req, upstream, peer).await;
    }

    // Regular HTTP proxy (GET, POST, PUT, DELETE, etc.)
    let stream = match timeout(Duration::from_secs(10), TcpStream::connect(&upstream)).await {
        Ok(Ok(s)) => s,
        Ok(Err(e)) => {
            tracing::error!("Failed to connect to upstream {}: {}", upstream, e);
            return Ok(Response::builder()
                .status(StatusCode::BAD_GATEWAY)
                .body(Full::from(Bytes::from("Bad Gateway - Upstream unreachable")))
                .unwrap());
        }
        Err(_) => {
            tracing::error!("Timeout connecting to upstream {}", upstream);
            return Ok(Response::builder()
                .status(StatusCode::GATEWAY_TIMEOUT)
                .body(Full::from(Bytes::from("Gateway Timeout - Upstream connection")))
                .unwrap());
        }
    };

    let io = TokioIo::new(stream);

    let (mut sender, conn) = ClientBuilder::new().handshake(io).await?;

    tokio::spawn(async move {
        let _ = conn.await;
    });

    let path = req.uri().path().to_string();
    let query = req.uri().query().map(|q| format!("?{}", q)).unwrap_or_default();

    *req.uri_mut() = format!("{}{}", path, query).parse().unwrap();

    let headers = req.headers_mut();
    headers.remove(header::HOST);
    if let Ok(host_value) = upstream.parse() {
        headers.insert(header::HOST, host_value);
    }

    let forwarded_for = match headers.get("X-Forwarded-For") {
        Some(existing) => format!("{}, {}", existing.to_str().unwrap_or(""), peer.ip()),
        None => peer.ip().to_string(),
    };
    if let Ok(value) = forwarded_for.parse() {
        headers.insert("X-Forwarded-For", value);
    }

    let upstream_res = match timeout(Duration::from_secs(60), sender.send_request(req)).await {
        Ok(Ok(res)) => res,
        Ok(Err(e)) => return Err(e),
        Err(_) => {
            tracing::error!("Timeout waiting for upstream response from {}", upstream);
            return Ok(Response::builder()
                .status(StatusCode::GATEWAY_TIMEOUT)
                .body(Full::from(Bytes::from("Gateway Timeout - Upstream response")))
                .unwrap());
        }
    };

    let mut response = Response::builder()
        .status(upstream_res.status())
        .version(upstream_res.version());

    for (key, value) in upstream_res.headers() {
        if key != header::CONNECTION && key != header::TRANSFER_ENCODING {
            response = response.header(key, value);
        }
    }

    let body_bytes = upstream_res.into_body().collect().await?.to_bytes();

    let response = response.body(Full::from(body_bytes)).unwrap();
    Ok(crate::headers::add_common_headers(response))
}

async fn proxy_websocket(
    mut req: Request<Incoming>,
    upstream: String,
    peer: SocketAddr,
) -> Result<Response<Full<Bytes>>, hyper::Error> {
    let client_upgrade = hyper::upgrade::on(&mut req);

    let upstream_stream = match TcpStream::connect(&upstream).await {
        Ok(s) => s,
        Err(e) => {
            tracing::error!("WS connect failed: {}", e);
            return Ok(Response::builder()
                .status(StatusCode::BAD_GATEWAY)
                .body(Full::from(Bytes::from("Bad Gateway - WS upstream")))
                .unwrap());
        }
    };

    let io = TokioIo::new(upstream_stream);
    let (mut sender, conn) = ClientBuilder::new().handshake(io).await?;

    tokio::spawn(async move {
        let _ = conn.await;
    });

    let path_and_query = req
        .uri()
        .path_and_query()
        .map(|pq| pq.to_string())
        .unwrap_or_else(|| "/".to_string());
    *req.uri_mut() = path_and_query.parse().unwrap();

    let headers = req.headers_mut();
    let forwarded_for = match headers.get("X-Forwarded-For") {
        Some(existing) => format!("{}, {}", existing.to_str().unwrap_or(""), peer.ip()),
        None => peer.ip().to_string(),
    };
    if let Ok(value) = forwarded_for.parse() {
        headers.insert("X-Forwarded-For", value);
    }

    let mut upstream_res = sender.send_request(req).await?;

    if upstream_res.status() != StatusCode::SWITCHING_PROTOCOLS {
        return Ok(Response::builder()
            .status(StatusCode::BAD_GATEWAY)
            .body(Full::from(Bytes::from("Bad Gateway - WS upgrade failed")))
            .unwrap());
    }

    let upstream_upgrade = hyper::upgrade::on(&mut upstream_res);

    let mut response = Response::builder()
        .status(StatusCode::SWITCHING_PROTOCOLS)
        .version(upstream_res.version());

    for (key, value) in upstream_res.headers() {
        if key != header::CONNECTION && key != header::UPGRADE {
            response = response.header(key, value);
        }
    }

    response = response.header(header::CONNECTION, "Upgrade");
    response = response.header(header::UPGRADE, "websocket");

    let response = response.body(Full::from(Bytes::new())).unwrap();

    tokio::spawn(async move {
        let client = match client_upgrade.await {
            Ok(u) => u,
            Err(e) => {
                tracing::error!("Client WS upgrade failed: {}", e);
                return;
            }
        };
        let upstream = match upstream_upgrade.await {
            Ok(u) => u,
            Err(e) => {
                tracing::error!("Upstream WS upgrade failed: {}", e);
                return;
            }
        };

        let mut client_io = TokioIo::new(client);
        let mut upstream_io = TokioIo::new(upstream);

        if let Err(e) = copy_bidirectional(&mut client_io, &mut upstream_io).await {
            tracing::debug!("WS proxy stream closed: {}", e);
        }
    });

    Ok(crate::headers::add_common_headers(response))
}
